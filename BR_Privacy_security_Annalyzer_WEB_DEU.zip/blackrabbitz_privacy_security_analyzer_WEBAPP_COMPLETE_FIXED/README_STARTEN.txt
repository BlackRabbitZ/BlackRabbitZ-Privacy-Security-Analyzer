BlackRabbitZ Privacy & Security Analyzer - WebApp

Windows:
1. ZIP entpacken.
2. logo.png im selben Ordner lassen/ersetzen.
3. start_blackrabbitz_privacy_security_analyzer.bat doppelklicken.

Alternativ: index.html direkt doppelklicken.

Es wird kein Webserver benötigt. Alles läuft lokal im Standardbrowser.
